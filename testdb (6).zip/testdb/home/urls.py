from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    # có thể thêm các url như đăng nhập, đăng xuất ở đây
    path('cart/', views.cart_view, name='cart'),
    path('add-to-cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
]