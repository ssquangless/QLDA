from django.shortcuts import render, redirect
from books.models import Book  # ✅ đúng vì Book nằm trong app books
from django.db.models import Q
import unicodedata
from django.urls import reverse

def strip_accents(text):
    return ''.join(c for c in unicodedata.normalize('NFD', text)
                   if unicodedata.category(c) != 'Mn').lower()

def home(request):
    # Lấy giá trị tìm kiếm và thể loại từ GET
    search_query = request.GET.get('q', '').strip()
    category_filter = request.GET.get('category', '')

    books = Book.objects.all()
    if category_filter:
        books = books.filter(category=category_filter)

    if search_query:
        search_query_nodau = strip_accents(search_query)
        books = [book for book in books if search_query_nodau in strip_accents(book.name)]

    # Chuyển CATEGORY_CHOICES sang list dict để dễ dùng ở template
    categories = [{'code': '', 'name': 'Tất cả'}] + [
        {'code': code, 'name': name} for code, name in Book.CATEGORY_CHOICES
    ]
    context = {
        'books': books,
        'categories': categories,
        'selected_category': category_filter,
        'search_query': search_query,
    }
    return render(request, 'home/home.html', context)

def cart_view(request):
    cart = request.session.get('cart', {})
    cart_items = []
    total_price = 0
    for book_id, quantity in cart.items():
        try:
            book = Book.objects.get(pk=book_id)
            item_total = book.price * quantity
            cart_items.append({
                'book': book,
                'quantity': quantity,
                'item_total': item_total,
            })
            total_price += item_total
        except Book.DoesNotExist:
            continue
    return render(request, 'home/cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
    })

def add_to_cart(request, book_id):
    if not request.user.is_authenticated:
        return redirect('%s?next=%s' % (reverse('login'), request.META.get('HTTP_REFERER', '/')))
    if request.user.is_staff:
        return redirect('home')
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        cart[str(book_id)] = cart.get(str(book_id), 0) + 1
        request.session['cart'] = cart
    return redirect('home')