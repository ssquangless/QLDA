from django.shortcuts import render, redirect, get_object_or_404
from .models import Book
from .forms import BookForm
from django.http import HttpResponse
from django.contrib.admin.views.decorators import staff_member_required
import unicodedata

def strip_accents(text):
    return ''.join(c for c in unicodedata.normalize('NFD', text)
                   if unicodedata.category(c) != 'Mn').lower()

def book_list(request):
    search_query = request.GET.get('q', '').strip()
    category_filter = request.GET.get('category', '')

    books = Book.objects.all()
    if category_filter:
        books = books.filter(category=category_filter)
    if search_query:
        search_query_nodau = strip_accents(search_query)
        books = [book for book in books if search_query_nodau in strip_accents(book.name)]

    categories = [{'code': '', 'name': 'Tất cả'}] + [
        {'code': code, 'name': name} for code, name in Book.CATEGORY_CHOICES
    ]
    return render(request, 'books/book_list.html', {
        'books': books,
        'categories': categories,
        'selected_category': category_filter,
        'search_query': search_query,
    })

def book_create(request):
    if request.method == 'POST':
        form = BookForm(request.POST, request.FILES)  # ✅ thêm request.FILES
        #form = BookForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm()
    return render(request, 'books/book_form.html', {'form': form})

def book_update(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        form = BookForm(request.POST, instance=book)
        if form.is_valid():
            form.save()
            return redirect('book_list')
    else:
        form = BookForm(instance=book)
    return render(request, 'books/book_form.html', {'form': form})

def book_delete(request, pk):
    book = get_object_or_404(Book, pk=pk)
    if request.method == 'POST':
        book.delete()
        return redirect('book_list')
    return render(request, 'books/book_confirm_delete.html', {'book': book})

def book_detail(request, pk):
    book = get_object_or_404(Book, pk=pk)
    return render(request, 'books/book_detail.html', {'book': book})
