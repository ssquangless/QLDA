from django.db import models
class Book(models.Model):
    CATEGORY_CHOICES = [
        ('Sách giáo khoa', 'Sách giáo khoa'),
        ('Sách tham khảo', 'Sách tham khảo'),
        ('Truyện tranh', 'Truyện tranh'),
        ('Tiểu thuyết', 'Tiểu thuyết'),
        ('Khoa học', 'Khoa học'),
        ('Lịch sử', 'Lịch sử'),
        ('Thiếu nhi', 'Thiếu nhi'),
        ('Giáo dục', 'Giáo dục'),
        ('Kỹ năng sống', 'Kỹ năng sống'),
        ('Lãng mạn', 'Lãng mạn'),
        ('Trinh thám', 'Trinh thám'),
        ('Giả tưởng', 'Giả tưởng'),
        ('Tiểu sử', 'Tiểu sử'),
        ('Kinh doanh', 'Kinh doanh'),
        ('Công nghệ', 'Công nghệ'),
        ('Du lịch', 'Du lịch'),
        ('Sức khỏe', 'Sức khỏe'),
]


    YEAR_CHOICES = [(year, str(year)) for year in range(1990, 2026)]

    name = models.CharField("Tên sách", max_length=200)
    category = models.CharField("Thể loại", max_length=100, choices=CATEGORY_CHOICES)
    publish_year = models.PositiveIntegerField("Năm xuất bản", choices=YEAR_CHOICES)
    publisher = models.CharField("Nhà xuất bản", max_length=200)
    quantity = models.PositiveIntegerField("Số lượng")
    price = models.DecimalField("Giá", max_digits=10, decimal_places=2)
    cover = models.ImageField("Ảnh bìa", upload_to='covers/', blank=True, null=True)
    descripcription = models.TextField("Mô tả", blank = True, null = True)
    # Nếu muốn tìm kiếm theo tác giả, thêm trường author ở đây
    # author = models.CharField("Tác giả", max_length=200, blank=True, null=True)
    created_at = models.DateTimeField("Ngày tạo", auto_now_add=True)
    updated_at = models.DateTimeField("Ngày cập nhật", auto_now=True)

    def __str__(self):
        return self.name
