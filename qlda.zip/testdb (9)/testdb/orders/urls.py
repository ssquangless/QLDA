from django.urls import path
from . import views

urlpatterns = [
    path('cart/', views.cart_view, name='cart'),
    path('add-to-cart/<int:book_id>/', views.add_to_cart, name='add_to_cart'),
    path('my-orders/', views.user_orders, name='user_orders'),
    path('orders/', views.admin_orders, name='admin_orders'),   # admin xem quản lý đơn hàng
    path('orders/<int:order_id>/update/', views.update_order_status, name='update_order_status'),
    path('cancel-order/<int:order_id>/', views.cancel_order, name='cancel_order'),
    path('admin-dashboard/', views.admin_dashboard, name='admin_dashboard'),
]