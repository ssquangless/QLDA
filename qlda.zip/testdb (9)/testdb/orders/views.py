from django.shortcuts import render, redirect, get_object_or_404
from books.models import Book
from .models import Order, OrderItem
from django.urls import reverse
from django.contrib.auth.decorators import login_required, user_passes_test
from django.http import JsonResponse, HttpResponseForbidden
from django.contrib.auth.models import User

@login_required
def cart_view(request):
    cart = request.session.get('cart', {})
    cart_items = []
    total_price = 0

    # Tạo danh sách sản phẩm trong giỏ hàng
    for book_id, quantity in cart.items():
        try:
            book = Book.objects.get(pk=book_id)
            item_total = book.price * quantity
            cart_items.append({
                'book': book,
                'quantity': quantity,
                'item_total': item_total,
            })
            total_price += item_total
        except Book.DoesNotExist:
            continue

    if request.method == 'POST':
        # Nếu chỉ là tăng số lượng
        if 'increase' in request.POST:
            book_id = request.POST['increase']
            if book_id in cart:
                cart[book_id] += 1
                request.session['cart'] = cart
            return redirect('cart')

        # Nếu chỉ là giảm số lượng
        if 'decrease' in request.POST:
            book_id = request.POST['decrease']
            if book_id in cart:
                if cart[book_id] > 1:
                    cart[book_id] -= 1
                else:
                    del cart[book_id]
                request.session['cart'] = cart
            return redirect('cart')

        # Nếu là đặt hàng
        if 'order' in request.POST:
            if not cart_items:
                return render(request, 'orders/cart.html', {
                    'cart_items': cart_items,
                    'total_price': total_price,
                    'error': 'Giỏ hàng trống, không thể đặt hàng.'
                })

            address = request.POST.get('address', '').strip()
            if not address:
                return render(request, 'orders/cart.html', {
                    'cart_items': cart_items,
                    'total_price': total_price,
                    'error': 'Bạn phải nhập địa chỉ giao hàng.'
                })

            # Tạo đơn hàng và các mục trong đơn hàng
            order = Order.objects.create(user=request.user, address=address)
            for item in cart_items:
                OrderItem.objects.create(
                    order=order,
                    book=item['book'],
                    quantity=item['quantity'],
                    price=float(item['book'].price)
                )

            request.session['cart'] = {}
            return render(request, 'orders/order_success.html', {'order': order})

    return render(request, 'orders/cart.html', {
        'cart_items': cart_items,
        'total_price': total_price,
    })

@login_required
def add_to_cart(request, book_id):
    if request.user.is_staff:
        return redirect('home')
    if request.method == 'POST':
        cart = request.session.get('cart', {})
        str_book_id = str(book_id)
        cart[str_book_id] = cart.get(str_book_id, 0) + 1
        request.session['cart'] = cart
    return redirect('home')

@login_required
def user_orders(request):
    status = request.GET.get('status', '')
    orders = Order.objects.filter(user=request.user).order_by('-created_at')
    if status:
        orders = orders.filter(status=status)
    status_choices = Order.STATUS_CHOICES
    # Danh sách id đơn hàng có thể hủy
    cancellable_ids = list(orders.filter(status__in=['pending', 'confirmed']).values_list('id', flat=True))
    return render(request, 'orders/user_orders.html', {
        'orders': orders,
        'status_choices': status_choices,
        'selected_status': status,
        'cancellable_ids': cancellable_ids,
    })

@user_passes_test(lambda u: u.is_staff)
def admin_orders(request):
    status = request.GET.get('status', '')
    orders = Order.objects.all().order_by('-created_at')
    if status:
        orders = orders.filter(status=status)
    return render(request, 'orders/admin_orders.html', {'orders': orders})

@user_passes_test(lambda u: u.is_staff)
def update_order_status(request, order_id):
    order = get_object_or_404(Order, id=order_id)
    prev_status = order.status  # Lưu trạng thái cũ
    if request.method == 'POST':
        new_status = request.POST.get('status')
        if new_status in dict(Order.STATUS_CHOICES):
            # Nếu chuyển từ trạng thái khác sang 'confirmed', cập nhật số lượng sách
            if prev_status != 'confirmed' and new_status == 'confirmed':
                for item in order.items.all():
                    book = item.book
                    if book.quantity >= item.quantity:
                        book.quantity -= item.quantity
                        book.save()
                    # Nếu muốn xử lý trường hợp hết hàng, có thể thêm else để báo lỗi
            order.status = new_status
            order.save()
        return redirect('admin_orders')
    return render(request, 'orders/update_status.html', {
        'order': order,
        'choices': Order.STATUS_CHOICES
    })

@login_required
def cancel_order(request, order_id):
    order = get_object_or_404(Order, id=order_id, user=request.user)
    if order.status not in ['pending', 'confirmed']:
        return HttpResponseForbidden("Không thể hủy đơn hàng này.")
    if request.method == 'POST':
        prev_status = order.status
        order.status = 'cancelled'
        order.save()
        # Nếu đơn đã xác nhận thì hoàn lại số lượng sách
        if prev_status == 'confirmed':
            for item in order.items.all():
                book = item.book
                book.quantity += item.quantity
                book.save()
        elif prev_status == 'pending':
            # Nếu muốn hoàn lại số lượng cho cả trạng thái pending (nếu đã trừ trước đó), thêm logic ở đây
            pass
        return JsonResponse({'success': True})
    return HttpResponseForbidden("Phương thức không hợp lệ.")

@user_passes_test(lambda u: u.is_staff)
def admin_dashboard(request):
    total_books = Book.objects.count()
    total_orders = Order.objects.count()
    confirmed_orders = Order.objects.filter(status='confirmed')
    total_confirmed_orders = confirmed_orders.count()
    total_revenue = sum(order.total_price() for order in confirmed_orders)
    total_users = User.objects.count()
    return render(request, 'orders/admin_dashboard.html', {
        'total_books': total_books,
        'total_orders': total_orders,
        'total_confirmed_orders': total_confirmed_orders,
        'total_revenue': total_revenue,
        'total_users': total_users,
    })