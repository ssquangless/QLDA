from django.shortcuts import render
from books.models import Book  # ✅ đúng vì Book nằm trong app books
from django.db.models import Q
import unicodedata

def strip_accents(text):
    return ''.join(c for c in unicodedata.normalize('NFD', text)
                   if unicodedata.category(c) != 'Mn').lower()

def home(request):
    # Lấy giá trị tìm kiếm và thể loại từ GET
    search_query = request.GET.get('q', '').strip()
    category_filter = request.GET.get('category', '')

    books = Book.objects.all()
    if category_filter:
        books = books.filter(category=category_filter)

    if search_query:
        search_query_nodau = strip_accents(search_query)
        books = [book for book in books if search_query_nodau in strip_accents(book.name)]

    # Chuyển CATEGORY_CHOICES sang list dict để dễ dùng ở template
    categories = [{'code': '', 'name': 'Tất cả'}] + [
        {'code': code, 'name': name} for code, name in Book.CATEGORY_CHOICES
    ]
    context = {
        'books': books,
        'categories': categories,
        'selected_category': category_filter,
        'search_query': search_query,
    }
    return render(request, 'home/home.html', context)